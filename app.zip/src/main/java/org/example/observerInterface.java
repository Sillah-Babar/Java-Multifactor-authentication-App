package org.example;
public interface observerInterface {
    public String updateRegistrationStatus(boolean isRegistered);
}